from app.trainers.trainer import CaseSession
from app.adapters.yandex_gpt import gpt_evaluate
from app.utils.case_state import get_user_case_session
from app.adapters.telegram import send_message, send_keyboard

import json

def parse_score_feedback(score_feedback):
    try:
        data = json.loads(score_feedback)
        return data.get("score"), data.get("comment", "")
    except Exception:
        return None, score_feedback.strip()

def handle_case_voice(chat_id: int, file_id: str):
    try:
        send_message(chat_id, "[DEBUG] handle_case_voice стартует")
        session = get_user_case_session(chat_id)
        send_message(chat_id, f"[DEBUG] session: {session}")
        from app.handlers.voice import stt_to_text
        user_answer_text = stt_to_text(file_id)
        send_message(chat_id, f"[DEBUG] stt_to_text вернул: {user_answer_text}")

        step = session.get_current_step()
        send_message(chat_id, f"[DEBUG] step: {step}")

        if step is None:
            send_message(chat_id, "[DEBUG] step is None — тренажёр завершён!")
            from app.utils.case_state import set_user_case_session
            set_user_case_session(chat_id, None)
            return

        eval_type = step['evaluation']
        crit = session.criteria[eval_type]
        send_message(chat_id, f"[DEBUG] eval_type: {eval_type}, crit: {crit}")

        score_feedback = gpt_evaluate(
            text=user_answer_text,
            prompt=crit['prompt'],
            scale=crit['scale'],
            feedback=crit.get('feedback', False)
        )
        send_message(chat_id, f"[DEBUG] score_feedback: {score_feedback}")

        score, feedback = parse_score_feedback(score_feedback)
        send_message(chat_id, f"[DEBUG] parse_score_feedback: score={score}, feedback={feedback}")

        session.save_result(step['id'], user_answer_text, score, feedback)
        send_message(chat_id, f"[DEBUG] save_result: {session.results}")

        next_step = session.next_step()
        send_message(chat_id, f"[DEBUG] next_step: {next_step}")

        if next_step:
            send_message(
                chat_id,
                f"Оценка: {score if score is not None else '-'}\nКомментарий: {feedback}\n\nСледующий шаг:\n📝 {next_step['question']}"
            )
        else:
            send_message(
                chat_id,
                f"Оценка: {score if score is not None else '-'}\nКомментарий: {feedback}\n\n👍 Все этапы пройдены! Для получения отчёта нажмите кнопку ниже."
            )
            send_keyboard(chat_id, [["Завершить тренажёр"]])
    except Exception as e:
        import traceback
        err_text = traceback.format_exc()
        send_message(chat_id, f"❗️Ошибка в handle_case_voice: {e}\n{err_text}")

def handle_case_text(chat_id: int, text: str):
    try:
        send_message(chat_id, f"[DEBUG] handle_case_text: chat_id={chat_id}, text={text}")
        session = get_user_case_session(chat_id)
        send_message(chat_id, f"[DEBUG] session: {session}")
        if not session:
            send_message(chat_id, "[DEBUG] Нет сессии! Попробуйте снова.")
            return

        step = session.get_current_step()
        send_message(chat_id, f"[DEBUG] current step: {step}")
        if step is None:
            send_message(chat_id, "[DEBUG] step is None — тренажёр завершён!")
            from app.utils.case_state import set_user_case_session
            set_user_case_session(chat_id, None)
            return

        session.save_result(step['id'], text, None, None)
        send_message(chat_id, f"[DEBUG] save_result called. Results: {session.results}")

        next_step = session.next_step()
        send_message(chat_id, f"[DEBUG] next_step: {next_step}")

        if next_step:
            send_message(chat_id, f"📝 {next_step['question']} [DEBUG: next_step: {next_step['id']}]")
        else:
            send_message(chat_id, "👍 Все этапы пройдены! Для получения отчёта нажмите кнопку ниже. [DEBUG: next_step None]")
            send_keyboard(chat_id, [["Завершить тренажёр"]])

    except Exception as e:
        import traceback
        err_text = traceback.format_exc()
        send_message(chat_id, f"❗️Ошибка в handle_case_text: {e}\n{err_text}")

def finish_case(chat_id: int):
    try:
        send_message(chat_id, "[DEBUG] finish_case стартует")
        session = get_user_case_session(chat_id)
        if not session:
            send_message(chat_id, "[DEBUG] Нет активной сессии тренажёра.")
            return
        pdf_path = f"/tmp/{chat_id}_report.pdf"
        all_answers = "\n".join([str(r['answer']) for r in session.results if r.get('answer')])
        summary = None
        try:
            summary = gpt_evaluate(
                text=all_answers,
                prompt="Ты — эксперт B2B-продаж. Подведи итог по всему тренажёру: выдели сильные стороны, зоны роста, дай рекомендации. Не повторяй ответы дословно."
            )
            send_message(chat_id, f"[DEBUG] gpt_evaluate summary: {summary}")
        except Exception as e:
            send_message(chat_id, f"[DEBUG] Ошибка в gpt_evaluate summary: {e}")
            summary = None
        session.export_pdf(pdf_path, summary=summary)
        from app.adapters.telegram import send_document
        send_document(chat_id, pdf_path, caption="Ваш отчёт по тренажёру!")
        send_message(chat_id, "🎉 Тренажёр завершён! Отчёт отправлен.")
        from app.utils.case_state import set_user_case_session
        set_user_case_session(chat_id, None)
    except Exception as e:
        import traceback
        err_text = traceback.format_exc()
        send_message(chat_id, f"❗️Ошибка в finish_case: {e}\n{err_text}")