from fpdf import FPDF

class PDF(FPDF):
    def header(self):
        # Фирменный зелёный MegaFon
        self.set_fill_color(110, 198, 68)
        self.rect(0, 0, 210, 18, 'F')
        self.set_font('Arial', 'B', 15)
        self.set_text_color(255,255,255)
        self.cell(0, 10, 'Отчёт по тренажёру B2B', 0, 1, 'C')
        self.ln(4)
        self.set_text_color(0,0,0)

    def section_title(self, title):
        self.set_font('Arial', 'B', 12)
        self.set_text_color(0, 102, 51)
        self.cell(0, 10, title, ln=True)
        self.set_text_color(0, 0, 0)
        self.ln(3)

def make_pdf_report(case, results, filename, user_name=None, start_time=None, summary=None):
    pdf = PDF()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)


    # Инфо о тренажёре и пользователе
    pdf.set_font('Arial', '', 12)
    pdf.cell(0, 10, f"Тренажёр: {case.get('name', '')}", ln=True)
    pdf.ln(1)
    pdf.set_font('Arial', 'I', 10)
    pdf.multi_cell(0, 7, f"Описание: {case.get('description', '')}")
    pdf.set_font('Arial', '', 12)
    pdf.cell(0, 10, f"Пользователь: {user_name or '-'}", ln=True)
    if start_time:
        pdf.cell(0, 10, f"Дата: {start_time.strftime('%d.%m.%Y %H:%M')}", ln=True)
    pdf.ln(4)

    pdf.section_title("Результаты шагов:")

    # Таблица (Вопрос - Ответ - Баллы - Комментарий)
    pdf.set_font('Arial', 'B', 11)
    pdf.set_fill_color(0, 185, 86)  # Мегафон-зелёный
    pdf.set_text_color(255)
    pdf.cell(68, 8, "Вопрос", 1, 0, 'C', fill=True)
    pdf.cell(50, 8, "Ответ", 1, 0, 'C', fill=True)
    pdf.cell(15, 8, "Баллы", 1, 0, 'C', fill=True)
    pdf.cell(45, 8, "Комментарий", 1, 1, 'C', fill=True)

    pdf.set_font('Arial', '', 11)
    pdf.set_text_color(30, 30, 30)
    total_score = 0
    for i, res in enumerate(results):
        step = next((s for s in case.get('steps', []) if s['id'] == res['step_id']), {})
        question = step.get('question', '')[:60]
        answer = (str(res.get('answer', '')) or '')[:35]
        score = str(res.get('score', ''))
        feedback = (str(res.get('feedback', '')) or '')[:30]
        pdf.cell(68, 8, question, 1)
        pdf.cell(50, 8, answer, 1)
        pdf.cell(15, 8, score, 1, 0, 'C')
        pdf.cell(45, 8, feedback, 1, 1)
        if isinstance(res.get('score'), int):
            total_score += res['score']

    pdf.ln(5)
    pdf.set_font('Arial', 'B', 13)
    pdf.set_text_color(0, 185, 86)
    pdf.cell(0, 10, f"Итоговый балл: {total_score}", ln=True)

    # Общий комментарий (summary, если есть)
    if summary:
        pdf.ln(5)
        pdf.set_font('Arial', 'B', 12)
        pdf.set_text_color(0, 185, 86)
        pdf.cell(0, 10, "Общий разбор:", ln=True)
        pdf.set_font('Arial', '', 11)
        pdf.set_text_color(30, 30, 30)
        pdf.multi_cell(0, 8, summary)

    pdf.output(filename)
