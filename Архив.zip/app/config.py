import os

TG_TOKEN   = os.environ["TG_TOKEN"]
YC_API_KEY = os.environ["YC_API_KEY"]
FOLDER_ID  = os.environ["YC_FOLDER_ID"]

# Все токены и ключи. Если надо что‑то ещё – добавляй тут